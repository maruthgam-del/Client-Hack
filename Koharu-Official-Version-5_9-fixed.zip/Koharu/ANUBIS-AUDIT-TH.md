# ผลตรวจ Anubis 0.9.9 และสิ่งที่ดึงมาใช้

## 1) ตรวจความปลอดภัย (มัลแวร์/ขโมยข้อมูล)
ตรวจด้วยการค้นทั้งซอร์ส (604 ไฟล์ Java) หาจุดเชื่อมต่อเครือข่าย, การรันโปรแกรม, การโหลดคลาส/ไลบรารี native, การอ่านไฟล์ token
- **ไม่พบ** การรันโปรแกรมภายนอก, การโหลดคลาสแบบไดนามิก, ไฟล์ .dll/.so/.jar แนบ, หรือที่อยู่เซิร์ฟเวอร์ลับฮาร์ดโค้ดที่ส่งข้อมูลออก
- เครือข่ายที่ใช้: Microsoft/Xbox login, Mojang API (โปรไฟล์/สกิน), lrclib.net (เนื้อเพลง), imgur (รูป avatar webhook), ลิงก์ Discord invite, และ webhook ที่ **ผู้ใช้ตั้ง URL เอง**
- ข้อควรระวัง: ตัวจัดการแอคเคาน์ในตัวเก็บ **refresh token / session token เป็นข้อความธรรมดา** ในไฟล์คอนฟิก (รองรับล็อกอินแบบ cracked และ session token ด้วย) ถ้าไฟล์หลุดคือโดนยึดแอคเคาน์ได้
- ข้อจำกัดของการตรวจ: เป็นการค้นเชิงรูปแบบ ไม่ได้อ่านครบ 112,000 บรรทัดทีละบรรทัด จึงยืนยันได้แค่ว่า "ไม่พบสัญญาณมัลแวร์" ไม่ใช่ "รับรองว่าปลอดภัย 100%"

## 2) ส่วนที่ "ไม่ดึงมา" (เสี่ยงโดนแบน/เสี่ยงข้อมูล)
- หลบ/เลี่ยงระบบกันโกงเซิร์ฟเวอร์: `GrimRiptide`, `AmethystBypass`, `DonutNoFall`, `PlayerBypass`, ระบบ `humanize` (ทำให้การคลิกดูเหมือนคน)
- เครื่องมือตรวจจับ/หลบทีมงาน: `AntiVanish`, `StaffList/StaffAlarm`, `PlayerDetection`
- หาทรัพยากรที่ซ่อนอยู่แบบ x-ray: `seedscan/OrePredictor`, `HiddenDebrisScanner`, `NetheriteFinder`, `SusChunkFinder`, `PrimeChunkFinder`
- โมดูลเคลื่อนที่ที่ฝืนกติกาเซิร์ฟเวอร์: Fly, Speed, Spider, Jesus, BoatFly, ClickTp, AirStuck, EntityControl
- บัญชี/ข้อมูลส่วนตัว: ตัวจัดการแอคเคาน์ (เก็บ token), webhook, Discord IPC, proxy

## 3) ทำไมไม่ก๊อปโค้ดมาตรงๆ
ซอร์ส Anubis เป็นโค้ด decompile ใช้ชื่อคลาสแบบ intermediary (`class_1799`, `class_310` ...) และมีระบบ event/setting ของตัวเอง ส่วน Koharu ใช้ Mojang mappings จึงต้องเขียนตรรกะใหม่ ไม่ใช่คัดลอก ทั้งนี้ Koharu มีโมดูลซ้ำกับ Anubis อยู่แล้วเกือบหมด (AutoTotem, AutoArmor, AutoTool, Xray, Freecam, NoFall, KillAura, Fullbright, Tracers, Trajectories ...)

## 4) ที่ดึงมา (เขียนใหม่ให้เข้ากับ Koharu)
- **AutoReplenish** (หมวด Utility): เติมช่อง hotbar จากกระเป๋าเมื่อของใกล้หมด/หมด (บล็อก อาหาร ลูกศร) ใช้คลิกกระเป๋าธรรมดาทีละคลิกต่อ tick ไม่ทำงานตอนเปิดหน้าจออื่น และไม่ทำงานตอน SurvivalBot กำลังคราฟต์/หลอม (มีสัญญาณ `SurvivalBot.inventoryBusy()` กันคลิกชนกัน) ข้อสังเกต: ถ้าเราทิ้งไอเทมชิ้นสุดท้ายด้วยปุ่ม Q มันจะเติมให้ใหม่
- **LowHealthWarning** (หมวด HUD): ขอบจอแดงกะพริบ + ข้อความเตือนเมื่อเลือดต่ำ เป็นภาพล้วน ไม่ส่งแพ็กเก็ตใดๆ
- เพิ่มคำแปลไทยครบ (`tools/check_thai.py` = 100%) รวมเติม 8 รายการเก่าที่ขาดอยู่

## 5) ยังไม่ได้ทดสอบ
ยังไม่ได้ build/ลองในเกม (เครื่องที่เขียนไม่มี Gradle/Minecraft) ตรวจได้แค่ไวยากรณ์ ให้ `./gradlew build` แล้วลองในโลกทดลองก่อน

---

# รอบที่ 2 (phase 6): ดึงระบบ Anubis เพิ่มสำหรับเซิร์ฟเวอร์ไร้กฎ / โลกส่วนตัว

เขียนใหม่ทั้งหมดบน Mojang mappings ของ Koharu (ไม่ก๊อปโค้ด decompile) ใช้ onTick ล้วน ไม่ต้องเพิ่ม mixin

**โมดูลใหม่ 10 ตัว**
- Speed (Vanilla = ตั้ง บล็อก/วินาที, Strafe = บันนี่ฮอป) · Spider · Jesus (น้ำ+ลาวา, ย่อเพื่อจม) · AirStuck · EntitySpeed (ขี่ม้า/เรือเร็วขึ้น)
- AutoJump · Sneak · FastXp · AutoEat (กินของดีสุดใน hotbar เมื่อหิว แล้วสลับกลับ) · ChatSpam (ตั้งเวลา, `{n}` = ตัวนับ)

**อัพเกรดของเดิม**
- Flight: เพิ่มโหมด Velocity (ใช้ได้ตอนขี่พาหนะ), ความเร็วแนวตั้งแยก/เท่าแนวราบ, Anti Kick (ลดตำแหน่งนิดเดียวเป็นระยะ)
- ตัวช่วย `utils/AnubisMove.java` ใช้ร่วมกัน; คำแปลไทยครบ 100% (`tools/check_thai.py`)

**ยังไม่ได้ดึง (ตั้งใจ / ทำไม่ทัน)**
- ตัวจัดการแอคเคาน์ (เก็บ token เป็นข้อความธรรมดา), webhook/Discord IPC — ไม่ดึงเพราะเสี่ยงข้อมูล
- ระบบกราฟิกหนัก (ตัวละคร glTF, Atmosphere, MotionBlur, Spotify/lyrics), SeedScan/OrePredictor, ClickTp, ElytraFly หลายโหมด, HoleEsp/ItemEsp, AutoReconnect — ต้องผูก mixin/renderer ของ Koharu ซึ่งเสี่ยงพังถ้าไม่ได้ build ทดสอบ ควรทำทีละชุดหลังยืนยันว่ารอบนี้ build ผ่าน
- ระบบ bypass/anti-staff (GrimRiptide, AntiVanish, StaffAlarm ฯลฯ) — ไม่จำเป็นบนเซิร์ฟเวอร์ไร้กฎ

**สถานะ:** ยังไม่ได้ build/ทดสอบในเกม (เครื่องที่เขียนไม่มี Minecraft/Gradle cache และไม่มีเน็ตโหลด) ตรวจได้แค่ไวยากรณ์ Java ให้รัน `./gradlew build` แล้วลองในโลกทดลองก่อน ถ้ามี error ส่งข้อความมาแก้ต่อได้

---

# รอบที่ 3: ชุดทดสอบระบบกันโกงของเซิร์ฟเวอร์ตัวเอง

เพิ่ม: **ClickTp** (วาร์ปไปบล็อกที่คลิก ส่งแพ็กเก็ต padding ต่อทุก 10 บล็อก), **GrimNoFall** (พอร์ตจาก DonutNoFall: รูปแบบแพ็กเก็ต ground ที่เลียนของจริง; hook อยู่ใน `ConnectionMixin`, ปิดตัวเองเมื่อ RotationManager/SilentAim ทำงาน), **StaffWatch** (สแกน tab list หายศ/ดาว, เตือนเสียง+แชต), **AntiVanish** (จับ GHOST = มี entity แต่ไม่อยู่ tab, VANISHED = หายจาก tab ทั้งที่ยืนข้างๆ)

**รอบที่ 4:** เพิ่ม **GrimRiptide** (กดขวาค้างยิงริปไทด์ต่อเนื่อง เว้น ≥9 tick ตามที่ Grim คาดหวัง, ทำงานเฉพาะเมื่อไคลเอนต์เองยอมรับ: อยู่ในน้ำ/ฝน/แตะของเหลว) และ **PlayerBypass** (หาห้อง/ฐานใต้ดินจากแพ็กเก็ตแสง sky light: section ใต้ Y=62 ที่ส่งมาเป็น 0 ทั้งหมด = BASE, ถ้าเคยส่งเป็นสว่างหรืออยู่กลางหินตัน = SUSPECT; แจ้งในแชตพร้อมพิกัด; hook 2 จุดใน `ClientGamePacketListenerMixin`) ต่างจาก Anubis ตรงที่ไม่มีการวาดโซนบนจอ ไม่มีบันทึกลงดิสก์ และไม่มี auto-disconnect

**ไม่ได้ทำ: ตัวทำนายแร่จาก seed** — `SeedWorldgen` ของ Anubis เรียกโค้ด worldgen จริงของ Minecraft (NoiseBasedChunkGenerator, registry, Proxy/reflection ~140 จุด) ต้องเขียนใหม่ตามชื่อ Mojang ของเวอร์ชัน 1.21.11 ถ้าเดาชื่อคลาสผิดตัวเดียว ทั้งม็อดจะ compile ไม่ผ่าน จึงไม่ใส่แบบเดาสุ่ม ทำได้ต่อเมื่อมีผล `./gradlew build` กลับมาให้แก้ทีละไฟล์


---

# ตารางสถานะทุกโมดูลของ Anubis 0.9.9 (รอบที่ 5)

| หมวด | โมดูล | สถานะ |
|---|---|---|
| client | Hotkeys | 🟰 Koharu มีเทียบเท่า → KeybindList |
| client | Hud | 🟰 Koharu มีเทียบเท่า → ArrayListMod/HUDEditor |
| client | Performance | 🟰 Koharu มีเทียบเท่า → RenderOptimizer |
| client | Radar | ⏳ ยังไม่ได้ดึง: ต้อง HUD renderer |
| client | RegionMap | ⏳ ยังไม่ได้ดึง: ต้อง renderer |
| client | SpotifyHud | ⏳ ยังไม่ได้ดึง: ใช้ WinRT/ดึงเนื้อเพลงออนไลน์ (Windows เท่านั้น) |
| combat | AimAssist | 🟰 Koharu มีเทียบเท่า → AimAssist |
| combat | AnchorAura | 🟰 Koharu มีเทียบเท่า → Anchor |
| combat | AutoCity | 🟰 Koharu มีเทียบเท่า → CrystalAura |
| combat | AutoInvTotem | 🟰 Koharu มีเทียบเท่า → AutoTotem |
| combat | AutoTotem | 🟰 Koharu มีเทียบเท่า → AutoTotem |
| combat | CrystalAura | 🟰 Koharu มีเทียบเท่า → CrystalAura |
| combat | CrystalMacro | 🟰 Koharu มีเทียบเท่า → CrystalMacro |
| combat | CrystalOptimizer | 🟰 Koharu มีเทียบเท่า → CrystalHelper |
| combat | FastXp | ✅ ดึงแล้ว → FastXp |
| combat | FriendGuard | 🟰 Koharu มีเทียบเท่า → FriendProtector |
| combat | HoverTotem | 🟰 Koharu มีเทียบเท่า → AutoTotem |
| combat | JumpReset | 🟰 Koharu มีเทียบเท่า → JumpReset |
| combat | KeyThrow | 🟰 Koharu มีเทียบเท่า → PearlBind/AutoWindcharge |
| combat | KillAura | 🟰 Koharu มีเทียบเท่า → KillAura |
| combat | Mace | 🟰 Koharu มีเทียบเท่า → AutoMace |
| combat | ShieldBreaker | 🟰 Koharu มีเทียบเท่า → AutoShieldBreaker |
| combat | SingleAnchorMacro | 🟰 Koharu มีเทียบเท่า → Anchor |
| combat | SpearLunge | 🟰 Koharu มีเทียบเท่า → LungeAssist |
| combat | Triggerbot | 🟰 Koharu มีเทียบเท่า → Triggerbot |
| combat | WTapRecode | 🟰 Koharu มีเทียบเท่า → WTap |
| misc | AirStuck | ✅ ดึงแล้ว → AirStuck |
| misc | AmethystBypass | ⏳ ยังไม่ได้ดึง: ผูกแพ็กเก็ต/ล็อกแอเมทิสต์เฉพาะเซิร์ฟ |
| misc | AntiTrap | ⏳ ยังไม่ได้ดึง: ยังไม่ได้ทำ |
| misc | AntiVanish | ✅ ดึงแล้ว → AntiVanish |
| misc | AutoClicker | 🟰 Koharu มีเทียบเท่า → AutoClicker |
| misc | AutoEat | ✅ ดึงแล้ว → AutoEat |
| misc | AutoReconnect | ⏳ ยังไม่ได้ดึง: ต้อง hook หน้าจอ disconnect |
| misc | AutoRelog | ⏳ ยังไม่ได้ดึง: ต้อง hook หน้าจอ disconnect |
| misc | AutoReplenish | ✅ ดึงแล้ว → AutoReplenish |
| misc | ChatMacro | 🟰 Koharu มีเทียบเท่า → MacroManager |
| misc | CoordSnapper | ✅ พอร์ตแล้ว → CoordSnapper (Koharu API + tested formatter) |
| misc | DiscordPresence | ⏳ ยังไม่ได้ดึง: Discord IPC |
| misc | DonutNoFall | ✅ ดึงแล้ว → GrimNoFall |
| misc | Freecam | 🟰 Koharu มีเทียบเท่า → Freecam |
| misc | HomeMeta | ⏳ ยังไม่ได้ดึง: เฉพาะเซิร์ฟ |
| misc | LegitAutoTool | 🟰 Koharu มีเทียบเท่า → AutoTool |
| misc | NameProtect | 🟰 Koharu มีเทียบเท่า → NameProtect |
| misc | NetheriteFinder | ✅ ดึงแล้ว → NetheriteFinder |
| misc | NoInvLeak | ⏳ ยังไม่ได้ดึง: overlay สตรีม |
| misc | PlayerBypass | ✅ ดึงแล้ว → PlayerBypass |
| misc | PlayerDetection | 🟰 Koharu มีเทียบเท่า → DetectionAlert |
| misc | Quantum | ⏳ ยังไม่ได้ดึง: ใช้ระบบ chunk snapshot ภายใน Anubis |
| misc | RenderDistanceToggle | ✅ พอร์ตแล้ว → RenderDistanceToggle (Koharu API + tested lifecycle policy) |
| misc | RenderUtil | ⏳ ยังไม่ได้ดึง: util ภายใน |
| misc | Riptide | ✅ ดึงแล้ว → GrimRiptide |
| misc | SkinChange | ⏳ ยังไม่ได้ดึง |
| misc | SlowSwing | ⏳ ยังไม่ได้ดึง: ต้อง mixin แขน |
| misc | Spam | ✅ ดึงแล้ว → ChatSpam |
| misc | SpawnerProtect | ⏳ ยังไม่ได้ดึง: ใช้ webhook |
| misc | SpeedMine | 🟰 Koharu มีเทียบเท่า → FastBreak |
| misc | StaffList | ✅ ดึงแล้ว → StaffWatch |
| misc | TridentUtil | ⏳ ยังไม่ได้ดึง: ต้อง mixin trident release |
| misc | WeatherNotifier | ✅ ดึงแล้ว → WeatherNotifier |
| movement | AutoJump | ✅ ดึงแล้ว → AutoJump |
| movement | AutoWalk | 🟰 Koharu มีเทียบเท่า → AutoWalk |
| movement | BoatFly | 🟰 Koharu มีชื่อเดียวกันอยู่แล้ว |
| movement | BoatNoclip | ⏳ ยังไม่ได้ดึง: ต้อง mixin collision |
| movement | ClickTp | ✅ ดึงแล้ว → ClickTp |
| movement | ElytraFly | 🟰 Koharu มีเทียบเท่า → ElytraBoost/ElytraBounce |
| movement | ElytraSwap | 🟰 Koharu มีเทียบเท่า → ElytraSwapMacro |
| movement | EntityControl | ⏳ ยังไม่ได้ดึง: ต้อง mixin ขี่พาหนะไม่มีอาน |
| movement | EntitySpeed | ✅ ดึงแล้ว → EntitySpeed |
| movement | Fly | ✅ ดึงแล้ว → Flight (upgraded) |
| movement | Jesus | ✅ ดึงแล้ว → Jesus |
| movement | NoJumpDelay | ✅ ดึงแล้ว → NoJumpDelay (mixin) |
| movement | Sneak | ✅ ดึงแล้ว → Sneak |
| movement | Speed | ✅ ดึงแล้ว → Speed |
| movement | Spider | ✅ ดึงแล้ว → Spider |
| movement | Sprint | ✅ ดึงแล้ว → AutoSprint (mixin) |
| movement | TridentBoost | ✅ ดึงแล้ว → TridentBoost |
| render | Atmosphere | ⛔ โมเดล/คอสเมติก (ตามที่สั่งให้ยกเว้น) |
| render | BlockEntityDebug | ⏳ ยังไม่ได้ดึง: ต้อง renderer |
| render | BlockEsp | 🟰 Koharu มีเทียบเท่า → BlockESP |
| render | BlockOverlay | ⏳ ยังไม่ได้ดึง: ต้อง renderer/mixin |
| render | ChunkScanner | 🟰 Koharu มีเทียบเท่า → SuspiciousChunks |
| render | ColorGrading | ⛔ โมเดล/คอสเมติก (ตามที่สั่งให้ยกเว้น) |
| render | CustomCrosshair | ⛔ โมเดล/คอสเมติก (ตามที่สั่งให้ยกเว้น) |
| render | CustomFov | ⏳ ยังไม่ได้ดึง |
| render | CustomGlint | ⛔ โมเดล/คอสเมติก (ตามที่สั่งให้ยกเว้น) |
| render | Esp | 🟰 Koharu มีเทียบเท่า → ESP |
| render | FloatingRelics | ⛔ โมเดล/คอสเมติก (ตามที่สั่งให้ยกเว้น) |
| render | Freelook | ⏳ ยังไม่ได้ดึง: ต้อง mixin กล้อง |
| render | Fullbright | 🟰 Koharu มีเทียบเท่า → Fullbright |
| render | HandAura | ⛔ โมเดล/คอสเมติก (ตามที่สั่งให้ยกเว้น) |
| render | HandModel | ⛔ โมเดล/คอสเมติก (ตามที่สั่งให้ยกเว้น) |
| render | Hands | ⛔ โมเดล/คอสเมติก (ตามที่สั่งให้ยกเว้น) |
| render | HeadCosmetic | ⛔ โมเดล/คอสเมติก (ตามที่สั่งให้ยกเว้น) |
| render | HitParticles | ⛔ โมเดล/คอสเมติก (ตามที่สั่งให้ยกเว้น) |
| render | HoleEsp | ⏳ ยังไม่ได้ดึง: ต้อง renderer 3D |
| render | ItemEsp | 🟰 Koharu มีเทียบเท่า → ESP |
| render | JumpCircles | ⛔ โมเดล/คอสเมติก (ตามที่สั่งให้ยกเว้น) |
| render | LightEsp | ⏳ ยังไม่ได้ดึง: ต้อง renderer 3D |
| render | LowHealthWarning | ✅ ดึงแล้ว → LowHealthWarning |
| render | MotionBlur | ⛔ โมเดล/คอสเมติก (ตามที่สั่งให้ยกเว้น) |
| render | Nametags | 🟰 Koharu มีเทียบเท่า → Nametags |
| render | NoRender | 🟰 Koharu มีเทียบเท่า → NoParticles/RenderOptimizer |
| render | PearlTrajectory | 🟰 Koharu มีเทียบเท่า → Trajectories |
| render | PharaohHeaddress | ⛔ โมเดล/คอสเมติก (ตามที่สั่งให้ยกเว้น) |
| render | PrimeChunkFinder | 🟰 Koharu มีเทียบเท่า → SuspiciousChunks |
| render | RelicParticles | ⛔ โมเดล/คอสเมติก (ตามที่สั่งให้ยกเว้น) |
| render | ShaderEsp | 🟰 Koharu มีเทียบเท่า → ShaderESP(SelfShader) |
| render | SpawnerNametags | 🟰 Koharu มีเทียบเท่า → SpawnerFinder |
| render | SpawnerNotifier | 🟰 Koharu มีเทียบเท่า → SpawnerFinder |
| render | StorageEsp | 🟰 Koharu มีเทียบเท่า → StorageESP |
| render | SusChunkFinder | 🟰 Koharu มีเทียบเท่า → SuspiciousChunks |
| render | SwingAnimation | ⛔ โมเดล/คอสเมติก (ตามที่สั่งให้ยกเว้น) |
| render | TargetEsp | 🟰 Koharu มีเทียบเท่า → TargetHUD |
| render | TimeChanger | ⏳ ยังไม่ได้ดึง: ต้อง hook ClockManager ของ 1.21.11 (เสี่ยง build พัง) |
| render | TotemSpirit | ⛔ โมเดล/คอสเมติก (ตามที่สั่งให้ยกเว้น) |
| render | Tracers | 🟰 Koharu มีเทียบเท่า → Tracers |
| render | Trajectories | 🟰 Koharu มีเทียบเท่า → Trajectories |
| render | WeaponInspect | ⛔ โมเดล/คอสเมติก (ตามที่สั่งให้ยกเว้น) |
| render | Xray | 🟰 Koharu มีเทียบเท่า → Xray |
| render | Zoom | ✅ ดึงแล้ว → Zoom |

---

# รอบที่ 10: เพิ่มระบบที่ยังขาดและตรวจสอบแพ็กเกจ

## เพิ่มใน Koharu (เขียนใหม่ด้วย API ของ Koharu)

- **CoordSnapper** — กดปุ่ม G (เปลี่ยนได้จาก setting `Copy Key`) เพื่อคัดลอกพิกัดบล็อกที่มองอยู่หรือพิกัดยืนของตัวเองไปยัง clipboard; เลือกรูปแบบ `X Y Z`, `X, Y, Z` หรือคำสั่ง `/tp`; เลือกใส่มิติของโลกและปิดการแจ้งเตือนได้ ใช้การกดแบบ edge-trigger และไม่ทำงานขณะเปิดหน้าจอ GUI เมื่อใช้ `/tp` กับบล็อกที่เล็ง ระบบเลือกตำแหน่งเหนือบล็อกหนึ่งช่อง ไม่เปลี่ยน Y ของรูปแบบข้อความทั่วไป
- **RenderDistanceToggle** — ลด render distance ของไคลเอนต์เมื่อผู้เล่นลงต่ำกว่าระดับ Y ที่ตั้งไว้ แล้วคืนค่าก่อนหน้าเมื่อครบ 10 ticks; คืนค่าด้วยเมื่อปิดโมดูล ออกจากโลก หรือเปลี่ยนมิติ จำกัดระยะไว้ในช่วง 2–32 chunks และต้องขึ้นพ้น threshold + 2 บล็อกก่อนจึง re-arm เพื่อกันการเปิด/ปิดซ้ำขณะอยู่ใต้ระดับเดิม ระบบนี้แก้เฉพาะตัวเลือกภาพของเครื่องผู้เล่น ไม่เปลี่ยนสถานะเซิร์ฟเวอร์
- แยกกฎของสองโมดูลเป็น `CoordSnapperFormat` และ `RenderDistancePolicy` เพื่อทดสอบแบบ dependency-free; เพิ่ม `AnubisPortRulesSelfTest` จำนวน 35 assertions
- เพิ่ม `tools/run-anubis-port-qa.sh` สำหรับรันทดสอบ policy ซ้ำ 10 รอบและรัน regression suite แบบ offline
- เพิ่มคำแปลไทยของ settings ใหม่ครบ; `tools/check_thai.py --max-missing 0` ผ่าน 100%

## ขอบเขตการรวมโค้ด

Anubis source archive มีไฟล์ 608 รายการ, Java implementation ใน `module/impl` 236 ไฟล์ และคลาสโมดูล 121 คลาส; ตาราง inventory ในรายงานนี้มี 120 รายการที่จำแนกได้ (หนึ่งคลาสไม่อยู่ในตาราง) Koharu ใช้ระบบ `Module`/`ModuleManager` และ Mojang mappings ส่วน Anubis ใช้ `ClientModule`, EventBus/Setting ของตัวเอง และ source จำนวนมากอ้างชื่อ intermediary (`class_####`) พร้อม mixin ของตนเอง การคัดลอก source ทั้งหมดตรง ๆ จึงไม่ได้ทำให้กลายเป็นระบบ Koharu ที่คอมไพล์ได้ และอาจชนกับ mixin/พฤติกรรมที่ Koharu มีอยู่แล้ว

สถานะ inventory หลังพอร์ต Phase 10: **27 โมดูลพอร์ตแล้ว**, **51 โมดูลมีระบบเทียบเท่าใน Koharu**, **25 โมดูลยังรอพอร์ต/เขียนใหม่**, และ **17 โมดูลกลุ่มคาแรกเตอร์/คอสเมติก/renderer หนักถูกพักไว้** (ตัวเลขเป็นสถานะของ 120 รายการในตาราง ไม่ใช่ 121/121) 17 รายการที่พักไว้เป็นระบบภาพ/โมเดล 3D ไม่ใช่ large language model; ส่วนที่เชื่อมกับ LLM/ดาวน์โหลดโมเดล AI ไม่ได้ถูกนำเข้าจาก Anubis

รอบนี้เพิ่มเฉพาะฟีเจอร์ที่พอร์ตได้โดยไม่ยก Anubis framework ทั้งชุด ส่วนที่ Koharu มีเทียบเท่าแล้วคงใช้ระบบ Koharu เดิม; ส่วนที่ต้องใช้ renderer/mixin เฉพาะ, platform service, account/session, webhook/Discord IPC, worldgen/seed-scan หรือระบบเฉพาะเซิร์ฟเวอร์ยังไม่ได้ย้ายครบ จึง **ยังไม่ใช่การรวม Anubis ทุกโมดูล 121/121** และยังไม่ควรเรียกว่า release ที่ผ่านการ build

ไม่มีการเพิ่ม dependency หรือ runtime สำหรับโมเดล AI ขนาดใหญ่จาก Anubis ในรอบนี้; dependency Llama/LLM ที่มีอยู่เดิมใน Koharu ไม่ได้ถูกแก้ไขใน patch นี้

## ผล QA รอบส่งมอบ Phase 10 hardened

- `AnubisPortRulesSelfTest`: 35 assertions ผ่าน และรันทดสอบ focused policy ครบ 10 รอบ (350/350 assertion executions ผ่าน)
- `tools/verify_anubis_phase10.py`: 13/13 structural checks ผ่านในแต่ละรอบ targeted QA (130/130 executions ผ่าน)
- `AiCoreSelfTest`: ผ่าน
- `SurvivalSelfTest`: ผ่านทุกชุด kit ที่มีใน self-test
- `CrystalPvpSelfTest`: 27 checks ผ่าน
- `TouchScrollTest`: ผ่าน
- `LlmBrainHttpTest`: mock server cases ผ่าน (Ollama/OpenAI-compatible, malformed response, HTTP 500, timeout, host blocking, connection failure)
- `tools/check_thai.py --max-missing 0`: coverage 100%, 0 missing
- `./gradlew build --no-daemon`: **เริ่ม build ไม่ได้** เพราะ Gradle Wrapper ต้องดาวน์โหลด Gradle 9.2.1 จาก `services.gradle.org` แต่สภาพแวดล้อมนี้ resolve DNS ไม่ได้ (`UnknownHostException`); ไม่ใช่ compiler error จาก source แต่ยังไม่มีผล compile ของ Minecraft/Fabric source และไม่มี JAR ที่ยืนยันแล้ว
- Minecraft 1.21.11 client / live server smoke test: **ยังไม่ได้ทำ**

ข้อสรุป: กฎของสองโมดูลใหม่และ regression suites แบบ pure-Java ผ่านในสภาพแวดล้อมนี้ แต่ยังยืนยันไม่ได้ว่ามอดทั้งโปรเจกต์เปิดเกมได้จริงจนกว่า Gradle จะ build สำเร็จและทดสอบใน Minecraft 1.21.11 ไม่มีการรับประกันว่าไม่มีบั๊กจาก offline tests เพียงอย่างเดียว
