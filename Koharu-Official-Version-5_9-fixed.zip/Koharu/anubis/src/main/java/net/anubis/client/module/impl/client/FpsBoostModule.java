package net.anubis.client.module.impl.client;

import net.anubis.client.event.EventHandler;
import net.anubis.client.event.Stage;
import net.anubis.client.event.impl.TickEvent;
import net.anubis.client.module.ClientModule;
import net.anubis.client.module.ModuleCategory;
import net.anubis.client.module.setting.BooleanSetting;
import net.anubis.client.module.setting.NumberSetting;
import net.anubis.client.util.FpsOptions;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;

/**
 * FPS Boost.
 *
 * <ul>
 *   <li><b>Unlock FPS</b> - raises "Max Framerate" (260 = Unlimited) and optionally turns VSync off.
 *       Your own video settings are saved when the module is enabled and put back when it is disabled
 *       (unless you changed them yourself in the meantime).</li>
 *   <li><b>Adaptive Boost</b> - while the real FPS is below the target, the background scan work of the
 *       other Anubis modules (see {@link PerformanceModule#scanBudgetNanos()}) is throttled
 *       proportionally, down to a configurable floor, and returns to full speed once FPS recovers.</li>
 * </ul>
 */
@Environment(EnvType.CLIENT)
public final class FpsBoostModule extends ClientModule {
   private static volatile FpsBoostModule active;

   private final NumberSetting maxFps = this.addSetting("max-fps", new NumberSetting("Max FPS (260 = Unlimited)", 260.0F, 10.0F, 260.0F).step(10.0F));
   private final BooleanSetting disableVsync = this.addSetting("disable-vsync", new BooleanSetting("Disable VSync", true));
   private final BooleanSetting adaptive = this.addSetting("adaptive-boost", new BooleanSetting("Adaptive Boost", true));
   private final NumberSetting targetFps = this.addSetting("target-fps", new NumberSetting("Target FPS", 120.0F, 30.0F, 360.0F).step(10.0F));
   private final NumberSetting minScanScale = this.addSetting("min-scan-scale", new NumberSetting("Min Scan Scale", 0.25F, 0.1F, 1.0F).step(0.05F));

   private boolean captured;
   private int savedMaxFps;
   private boolean savedVsync;
   private int appliedMaxFps = -1;
   private boolean vsyncForced;
   private float smoothedFps = -1.0F;
   private volatile float scanScale = 1.0F;

   public FpsBoostModule() {
      super("fps-boost", "FPS Boost", "Unlocks the FPS cap and throttles background scans when FPS is low.", ModuleCategory.CLIENT);
      this.targetFps.visibleWhen(this.adaptive::get);
      this.minScanScale.visibleWhen(this.adaptive::get);
   }

   /** Multiplier (0.1 - 1.0) applied to background scan budgets. 1.0 when the module is off or FPS is healthy. */
   public static float scanScale() {
      FpsBoostModule module = active;
      return module == null ? 1.0F : module.scanScale;
   }

   @Override
   protected void onEnable() {
      active = this;
      this.captured = false;
      this.appliedMaxFps = -1;
      this.vsyncForced = false;
      this.smoothedFps = -1.0F;
      this.scanScale = 1.0F;
      this.sync();
   }

   @Override
   protected void onDisable() {
      active = null;
      this.scanScale = 1.0F;
      this.smoothedFps = -1.0F;
      if (this.captured && FpsOptions.available()) {
         // Only give the settings back if they are still the ones we set; otherwise the player changed them.
         if (this.appliedMaxFps >= 0 && FpsOptions.maxFps() == this.appliedMaxFps) {
            FpsOptions.setMaxFps(this.savedMaxFps);
         }

         if (this.vsyncForced && !FpsOptions.vsync()) {
            FpsOptions.setVsync(this.savedVsync);
         }
      }

      this.captured = false;
      this.appliedMaxFps = -1;
      this.vsyncForced = false;
   }

   @EventHandler(stage = Stage.POST)
   public void onTick(TickEvent event) {
      this.sync();
      this.updateAdaptive();
   }

   private void sync() {
      if (!FpsOptions.available()) {
         return;
      }

      if (!this.captured) {
         this.savedMaxFps = FpsOptions.maxFps();
         this.savedVsync = FpsOptions.vsync();
         this.captured = true;
      }

      int wanted = this.maxFps.getInt();
      FpsOptions.setMaxFps(wanted);
      this.appliedMaxFps = wanted;

      if (this.disableVsync.get()) {
         if (FpsOptions.vsync()) {
            FpsOptions.setVsync(false);
         }

         this.vsyncForced = true;
      } else if (this.vsyncForced) {
         // The player un-ticked "Disable VSync" while running: hand VSync back.
         FpsOptions.setVsync(this.savedVsync);
         this.vsyncForced = false;
      }
   }

   private void updateAdaptive() {
      if (!this.adaptive.get()) {
         this.scanScale = 1.0F;
         this.smoothedFps = -1.0F;
         return;
      }

      class_310 mc = class_310.method_1551();
      int fps = mc == null ? 0 : mc.method_47599();
      if (fps <= 0) {
         return;
      }

      this.smoothedFps = this.smoothedFps < 0.0F ? fps : this.smoothedFps + (fps - this.smoothedFps) * 0.2F;
      float ratio = this.smoothedFps / Math.max(1.0F, this.targetFps.get());
      float floor = this.minScanScale.get();
      this.scanScale = Math.max(floor, Math.min(1.0F, ratio));
   }
}
