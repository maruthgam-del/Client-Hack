package net.anubis.client.util;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;

/**
 * Thin wrapper around the two vanilla video options the FPS Boost module touches.
 *
 * <p>All Minecraft names (Fabric Intermediary, 1.21.11) are kept in this one file on purpose:
 * if a build ever reports an unknown symbol for the FPS module, only the two
 * {@code method_*} calls below need to be checked.
 *
 * <ul>
 *   <li>{@code class_315.method_42524()} = {@code Options.framerateLimit()}  (OptionInstance&lt;Integer&gt;)</li>
 *   <li>{@code class_315.method_42433()} = {@code Options.enableVsync()}     (OptionInstance&lt;Boolean&gt;)</li>
 * </ul>
 *
 * Setting an option through its {@code OptionInstance} also fires the vanilla callback that pushes the
 * value to the window, so no direct GLFW call is needed.
 */
@Environment(EnvType.CLIENT)
public final class FpsOptions {
   /** In vanilla the "Max Framerate" slider tops out at 260, which the game treats as Unlimited. */
   public static final int UNLIMITED = 260;
   public static final int MIN_LIMIT = 10;

   private FpsOptions() {
   }

   public static boolean available() {
      return class_310.method_1551() != null && class_310.method_1551().field_1690 != null;
   }

   public static int maxFps() {
      return (Integer)class_310.method_1551().field_1690.method_42524().method_41753();
   }

   public static void setMaxFps(int value) {
      int clamped = Math.max(MIN_LIMIT, Math.min(UNLIMITED, value));
      if (maxFps() != clamped) {
         class_310.method_1551().field_1690.method_42524().method_41748(clamped);
      }
   }

   public static boolean vsync() {
      return (Boolean)class_310.method_1551().field_1690.method_42433().method_41753();
   }

   public static void setVsync(boolean value) {
      if (vsync() != value) {
         class_310.method_1551().field_1690.method_42433().method_41748(value);
      }
   }
}
